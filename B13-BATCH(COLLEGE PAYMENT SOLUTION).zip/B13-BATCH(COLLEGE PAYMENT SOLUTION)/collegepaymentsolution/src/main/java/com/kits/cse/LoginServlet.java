package com.kits.cse;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentid = request.getParameter("studentid");
        String studentname = request.getParameter("studentname");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection con = null;
        PreparedStatement ps = null, ps2 = null;
        ResultSet rs = null, rs2 = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/collegepaymentsolution", "root", "");

            // Authenticate user
            ps = con.prepareStatement("SELECT quota,branch FROM registration WHERE studentid=? AND studentname=?");
            ps.setString(1, studentid);
            ps.setString(2, studentname);
            rs = ps.executeQuery();

            if (rs.next()) {
                String quota = rs.getString("quota");
                String branch = rs.getString("branch");

                // Get fee amount from feequota
                ps2 = con.prepareStatement("SELECT amount FROM feequota WHERE quota=? and branch=?");
                ps2.setString(1, quota);
                ps2.setString(2, branch);
                rs2 = ps2.executeQuery();

                if (rs2.next()) {
                    double amount = rs2.getDouble("amount");
                    HttpSession session=request.getSession(true);
                    session.setAttribute("actualamount", amount);
                    // Generate transaction ID
                    String transactionId = generateTransactionId();

                    // Store session data
                    session.setAttribute("studentid", studentid);
                    session.setAttribute("studentname", studentname);
                    session.setAttribute("transactionId", transactionId);

                    out.println("<h2>Login Successful</h2>");
                    out.println("<p>Welcome, <strong>" + studentname + "</strong>!</p>");
                    out.println("<p>Your Quota: <strong>" + quota + "</strong></p>");
                    out.println("<p>Fee Amount: <strong>₹" + amount + "</strong></p>");
                    out.println("<p>Transaction ID: <strong>" + transactionId + "</strong></p>");
                    out.println("<p><a href='index.jsp?page=home'>Go to Dashboard</a></p>");
                } else {
                    out.println("<p>Error: Fee amount not found for quota: " + quota + "</p>");
                }

            } else {
                out.println("<h3>Invalid student ID or name.</h3>");
            }

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try { if (rs2 != null) rs2.close(); } catch (Exception ignored) {}
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps2 != null) ps2.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    private String generateTransactionId() {
        String datePart = new SimpleDateFormat("yyyyMMdd").format(new Date());
        int randomPart = new Random().nextInt(900000) + 100000; // 6 digit random number
        return "TXN-" + datePart + "-" + randomPart;
    }
}
