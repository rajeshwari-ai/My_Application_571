package com.kits.cse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String jdbcURL = "jdbc:mysql://localhost:3306/collegepaymentsolution";
        String dbUser = "root";
        String dbPassword = ""; // Add password if needed

        String selectedBranch = request.getParameter("branch");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // HTML Header and Styles
            out.println("<html><head><title>Admin View</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 20px; color: #333; }");
            out.println("h2 { color: #2c3e50; }");
            out.println("table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }");
            out.println("th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background-color: #3498db; color: white; }");
            out.println("tr:hover { background-color: #f1f1f1; }");
            out.println("a { text-decoration: none; color: #3498db; margin-right: 10px; }");
            out.println("a:hover { text-decoration: underline; }");
            out.println("</style></head><body>");

            // Navigation
            out.println("<div style='margin-bottom: 20px;'>");
            out.println("<a href='index.jsp'>Home</a> ");
           
            out.println("</div>");

            // Dropdown Form
            out.println("<form method='post' action='AdminServlet'>");
            out.println("Filter by Branch: ");
            out.println("<select name='branch' onchange='this.form.submit()'>");
            out.println("<option value=''>-- All Branches --</option>");
            out.println("<option value='CSE'" + ("CSE".equals(selectedBranch) ? " selected" : "") + ">CSE</option>");
            out.println("<option value='AIML'" + ("AIML".equals(selectedBranch) ? " selected" : "") + ">AIML</option>");
            out.println("<option value='EEE'" + ("EEE".equals(selectedBranch) ? " selected" : "") + ">EEE</option>");
            out.println("<option value='ECE'" + ("ECE".equals(selectedBranch) ? " selected" : "") + ">ECE</option>");
            out.println("</select>");
            out.println("</form><br>");

            out.println("<h2>Student Payment Records</h2>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Branch</th><th>Year</th><th>Quota</th><th>Email</th><th>Mobile</th><th>Amount</th></tr>");

            String sql = "SELECT studentid, studentname, branch, year, quota, email, mobile, amount FROM registration WHERE amount != 0";
            if (selectedBranch != null && !selectedBranch.isEmpty()) {
                sql += " AND branch = ?";
            }

            PreparedStatement ps = conn.prepareStatement(sql);
            if (selectedBranch != null && !selectedBranch.isEmpty()) {
                ps.setString(1, selectedBranch);
            }

            ResultSet rs = ps.executeQuery();
            boolean hasRecords = false;

            while (rs.next()) {
                hasRecords = true;
                out.println("<tr>");
                out.println("<td>" + rs.getString("studentid") + "</td>");
                out.println("<td>" + rs.getString("studentname") + "</td>");
                out.println("<td>" + rs.getString("branch") + "</td>");
                out.println("<td>" + rs.getString("year") + "</td>");
                out.println("<td>" + rs.getString("quota") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getString("mobile") + "</td>");
                out.println("<td>" + rs.getDouble("amount") + "</td>");
                out.println("</tr>");
            }

            if (!hasRecords) {
                out.println("<tr><td colspan='8'>No records found for selected branch.</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            conn.close();

        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        }
    }
}
