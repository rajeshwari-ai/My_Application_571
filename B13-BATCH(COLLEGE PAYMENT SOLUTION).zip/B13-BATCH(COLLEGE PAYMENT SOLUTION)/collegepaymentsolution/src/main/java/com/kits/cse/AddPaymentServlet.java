package com.kits.cse;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AddPaymentServlet")
public class AddPaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentId = request.getParameter("studentid");
        String amountStr = request.getParameter("amount");

        response.setContentType("text/html");

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            response.getWriter().println("<script>alert('Invalid amount'); window.location='index.jsp?page=add';</script>");
            return;
        }

        // Generate unique transaction ID
        String datePart = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        int randomPart = new Random().nextInt(900000) + 100000;
        String transactionId = "KITWPT" + datePart + "-" + randomPart;
        HttpSession session=request.getSession(false);
        double actual_amount=Double.parseDouble(session.getAttribute("actualamount").toString());
        System.out.println("STD QOUTA AMOUNT : "+actual_amount);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/collegepaymentsolution", "root", "");
                 PreparedStatement stmt = conn.prepareStatement(
                         "INSERT INTO payments (studentid, amount, transactionid) VALUES (?, ?, ?)")) {

                stmt.setString(1, studentId);
                stmt.setDouble(2, amount);
                stmt.setString(3, transactionId);
                
                int rows = stmt.executeUpdate();
                int student_id=Integer.parseInt(studentId);
                if (rows > 0) {
                	String query="select amount from registration where studentid ="+student_id;
                	System.out.println("QUERY "+query);
                	PreparedStatement pst=DBConnection.getStatement(query);
                	
                	
                	ResultSet rs=pst.executeQuery();
                	double total_fee=0.0;
                	double updated_fee=0.0;
                	if(rs.next()) {
                		total_fee=Double.parseDouble(rs.getString(1));
                		updated_fee=total_fee-amount;
                		System.out.println("TOTAL :"+total_fee);
                		System.out.println("AMOUNT PAID TODAY :"+amount);
                		System.out.println("UPDATED OR BALANCE : "+updated_fee);
                	}
                	PreparedStatement stmt2 = conn.prepareStatement("SELECT * FROM payments WHERE studentid = ?");
                    stmt2.setString(1, studentId);
                    ResultSet rs2 = stmt2.executeQuery();
                    double totalPaid=0;
                    while(rs2.next()) {
                    	totalPaid=totalPaid+Double.parseDouble(rs2.getString("amount"));
                    }
                    
                    System.out.println("TOTAL PAID : "+totalPaid);
                    System.out.println("ACTUAL QOUTA : "+actual_amount);
                    
                	if(total_fee>=updated_fee&&totalPaid<=actual_amount) {
                		System.out.println("update....");
                		int fee_status=DBConnection.getStatement("update registration set amount='"+updated_fee+"' where studentid="+student_id).executeUpdate();
                		if(fee_status>0) {
                    		
                    		response.getWriter().println("<script>alert('Payment added successfully! Transaction ID: "
                                + transactionId + "'); window.location='index.jsp?page=view';</script>");
                    } else {
                        response.getWriter().println("<script>alert('Payment not added. Please try again.'); window.location='index.jsp?page=add';</script>");
                    }
                	}else {
                		PreparedStatement pp=DBConnection.getStatement("delete from payments where transactionid=?");
                        pp.setString(1, transactionId);
                        pp.executeUpdate();
                		response.getWriter().println("<script>alert('Invalid Amount'); window.location='index.jsp?page=add';</script>");

                	}
                	
                	
                }
            }

        } catch (ClassNotFoundException e) {
            response.getWriter().println("<script>alert('JDBC Driver not found'); window.location='index.jsp?page=add';</script>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<script>alert('Database error: " + e.getMessage() + "'); window.location='index.jsp?page=add';</script>");
        }
    }
}
