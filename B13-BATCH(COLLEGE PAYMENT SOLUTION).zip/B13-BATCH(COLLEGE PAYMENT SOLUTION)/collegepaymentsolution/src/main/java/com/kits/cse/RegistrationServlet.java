package com.kits.cse;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html"); // Ensure proper HTML output

        String studentid = request.getParameter("studentid");
        String studentname = request.getParameter("studentname");
        String branch = request.getParameter("branch");
        String year = request.getParameter("year");
        String quota = request.getParameter("quota");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");

        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/collegepaymentsolution", "root", "");

            // Step 1: Fetch amount from feequota table
            PreparedStatement psFee = con.prepareStatement(
                "SELECT amount FROM feequota WHERE quota = ? and branch=?");
            psFee.setString(1, quota);
            psFee.setString(2, branch);
            ResultSet rs = psFee.executeQuery();

            String amount = null;
            if (rs.next()) {
                amount = rs.getString("amount");
            } else {
                out.println("<html><body>");
                out.println("<h3>Invalid quota selected.</h3>");
                out.println("<a href='index.jsp'>Go to Home Page</a>");
                out.println("</body></html>");
                con.close();
                return;
            }

            // Step 2: Insert into Registration table
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO Registration VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, studentid);
            ps.setString(2, studentname);
            ps.setString(3, branch);
            ps.setString(4, year);
            ps.setString(5, quota);
            ps.setString(6, email);
            ps.setString(7, mobile);
            ps.setString(8, amount);
            ps.executeUpdate();

            out.println("<html><body>");
            out.println("<h2>Registration successful!</h2>");
            out.println("<a href='index.jsp'>Go to Home Page</a>");
            out.println("</body></html>");

            con.close();

        } catch (Exception e) {
            out.println("<html><body>");
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            out.println("<a href='index.jsp'>Go to Home Page</a>");
            out.println("</body></html>");
        }
    }
}
