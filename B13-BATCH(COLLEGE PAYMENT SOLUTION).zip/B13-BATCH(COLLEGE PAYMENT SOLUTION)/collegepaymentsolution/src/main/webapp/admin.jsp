<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 350px;
      text-align: center;
    }

    h2 {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
      text-align: left;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      margin-top: 20px;
      width: 100%;
      padding: 10px;
      background-color: #007BFF;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }

    button:hover {
      background-color: #004080;
    }

    .home-link {
      margin-top: 15px;
      display: block;
      font-size: 14px;
      color: #007BFF;
      text-decoration: none;
    }

    .home-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <%
    String msg = request.getParameter("msg");
    if (msg != null) {
      out.println("<script>alert('Invalid username and password');</script>");
    }
  %>
  <div class="container">
    <h2>Admin Login</h2>
    <form action="AdminServlet" method="post">
      <label for="username">Username</label>
      <input type="text" name="username" required>

      <label for="password">Password</label>
      <input type="password" name="password" required>

      <button type="submit">Login</button>
    </form>
    <a class="home-link" href="index.jsp">Back to Home</a>
  </div>
</body>
</html>
