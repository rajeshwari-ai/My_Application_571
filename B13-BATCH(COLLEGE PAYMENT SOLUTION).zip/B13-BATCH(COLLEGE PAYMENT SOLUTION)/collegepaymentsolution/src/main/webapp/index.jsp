<%@ page import="java.sql.*" %>
<%@ page import="javax.servlet.http.HttpSession" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String pageType = request.getParameter("page");
    HttpSession Session = request.getSession(false);
    String studentId = null;
    String studentName = null;

    if (session != null) {
        studentId = (String) session.getAttribute("studentid");
        studentName = (String) session.getAttribute("studentname");
    }

    if ("logout".equals(pageType)) {
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect("index.jsp?page=home");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>College Payment Solution</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7fa;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #004080;
        }

        nav {
            text-align: center;
            background-color: #004080;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: white;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #ffd700;
        }

        .section {
            max-width: 700px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        form input, form select {
            margin: 10px 0;
            padding: 8px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form input[type="submit"] {
            background-color: #004080;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }

        form input[type="submit"]:hover {
            background-color: #0059b3;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th {
            background-color: #004080;
            color: white;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
        }

        .dashboard-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #004080;
            font-weight: bold;
        }

        .dashboard-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h1>College Payment Solution</h1>

<nav>
    <a href="index.jsp?page=home">Home</a>
    <% if (studentId == null) { %>
        <a href="index.jsp?page=register">Register</a>
        <a href="index.jsp?page=login">Login</a>
        <a href="admin.jsp?page=admin">admin</a>
    <% } else { %>
        <a href="index.jsp?page=view">View</a>
        <a href="index.jsp?page=add">Add</a>
        <a href="index.jsp?page=logout">Logout</a>
    <% } %>
</nav>

<div class="section">
<%
    if (pageType == null || pageType.equals("home")) {
%>
    <h2>Welcome</h2>
    <% if (studentId != null) { %>
        <p>Hello, <strong><%= studentName %></strong> (ID: <%= studentId %>)</p>
        <p>Welcome to the College Payment Portal.</p>
    <% } else { %>
        <p> College Payment Solution is used for managing college fee payments manually can be time-consuming and error-prone. This project presents a College Payment Solution developed using Java to simplify and digitize the fee payment process for students and administration.  and provide flexible options using secure digital systems.</p>
    <% }
    } else if (pageType.equals("register")) {
%>
    <h2>Registration Form</h2>
    <form action="RegistrationServlet" method="post">
        Student ID: <input type="text" name="studentid" required><br>
        Student Name: <input type="text" name="studentname" required><br>
        Branch:
        <select name="branch">
            <option value="select branch">select branch</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="EEE">EEE</option>
            <option value="AIML">AIML</option>
        </select><br>
        Year:
        <select name="year">
            <option value="select year">select year</option>
            <option value="1st">1st</option>
            <option value="2nd">2nd</option>
            <option value="3rd">3rd</option>
            <option value="4th">4th</option>
        </select><br>
        Quota:
        <select name="quota">
            <option value="select quota">select quota</option>
            <option value="convinier">convinier</option>
            <option value="Management">Management</option>
            <option value="minority">minority</option>
            <option value="Government">Government</option>
        </select><br>
        Email: <input type="email" name="email" required><br>
        Mobile: <input type="text" name="mobile" required><br>
        <input type="submit" value="Register">
    </form>
<%
    } else if (pageType.equals("login")) {
%>
    <h2>Login</h2>
    <form action="LoginServlet" method="post">
        Student ID: <input type="text" name="studentid" required><br>
        Student Name: <input type="text" name="studentname" required><br>
        <input type="submit" value="Login">
    </form>
<%
    } else if (pageType.equals("add")) {
        if (studentId == null) {
            response.sendRedirect("index.jsp?page=login");
            return;
        }
%>
    <h2>Add Payment</h2>
    <form action="AddPaymentServlet" method="post">
        Student ID: <input type="text" name="studentid" value="<%= studentId %>" readonly><br>
        Amount: <input type="text" name="amount" required><br>
        <input type="submit" value="Submit Payment">
    </form>
    <a href="index.jsp?page=home" class="dashboard-link">Go back to Dashboard</a>
<%
    } else if (pageType.equals("view")) {
        if (studentId == null) {
            response.sendRedirect("index.jsp?page=login");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        double totalFee = 0;
        double totalPaid = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/collegepaymentsolution", "root", "");

            // Step 1: Get total fee from Registration table
            stmt = conn.prepareStatement("SELECT amount FROM Registration WHERE studentid = ?");
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();
            if (rs.next()) {
                //totalFee = rs.getDouble("amount");
            	totalFee =Double.parseDouble(session.getAttribute("actualamount").toString());
          
            }
            rs.close();
            stmt.close();

            // Step 2: Get payments
            stmt = conn.prepareStatement("SELECT * FROM payments WHERE studentid = ?");
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();
%>
    <h2>Payment Records</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Amount</th>
            <th>Transaction ID</th>
            <th>Date</th>
        </tr>
<%
            while (rs.next()) {
                double paid = rs.getDouble("amount");
                totalPaid += paid;
%>
        <tr>
            <td><%= rs.getInt("id") %></td>
            <td><%= paid %></td>
            <td><%= rs.getString("transactionid") %></td>
            <td><%= rs.getTimestamp("date") %></td>
        </tr>
<%
            }

            double dueAmount = totalFee-totalPaid;
%>
    </table>
    <h3>Total Fee: ₹<%= totalFee %></h3>
    <h3>Total Paid: ₹<%= totalPaid %></h3>
    <h3 style="color: red;">Due Amount: ₹<%= dueAmount %></h3>
    <a href="index.jsp?page=home" class="dashboard-link">Go back to Dashboard</a>
<%
        } catch (Exception e) {
            out.println("Error fetching payment data.");
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
%>
</div>

</body>
</html>
