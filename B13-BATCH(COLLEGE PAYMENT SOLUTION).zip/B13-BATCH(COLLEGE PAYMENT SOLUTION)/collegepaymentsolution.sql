-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2025 at 08:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collegepaymentsolution`
--
CREATE DATABASE IF NOT EXISTS `collegepaymentsolution` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `collegepaymentsolution`;

-- --------------------------------------------------------

--
-- Table structure for table `feequota`
--

CREATE TABLE `feequota` (
  `id` int(10) NOT NULL,
  `quota` varchar(20) NOT NULL,
  `year` varchar(10) NOT NULL,
  `branch` varchar(10) NOT NULL,
  `amount` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feequota`
--

INSERT INTO `feequota` (`id`, `quota`, `year`, `branch`, `amount`) VALUES
(1, 'convinier', '1', 'cse', '5000'),
(2, 'Management', '1', 'cse', '50000'),
(3, 'minority', '1', 'cse', '5000'),
(4, 'Government', '1', 'cse', '2500');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(20) NOT NULL,
  `transactionid` varchar(50) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `studentid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `transactionid`, `amount`, `date`, `studentid`) VALUES
(1, 'TXN-20250507114253-977917', '1000.0', '2025-05-07', '88'),
(2, 'TXN-20250507120323-295483', '5000.0', '2025-05-07', '56'),
(3, 'TXN-20250507121448-787824', '1000.0', '2025-05-07', '56'),
(4, 'TXN-20250507121730-761676', '1000.0', '2025-05-07', '13'),
(5, 'TXN-20250507121802-435649', '1000.0', '2025-05-07', '13'),
(6, 'TXN-20250507122045-374834', '1000.0', '2025-05-07', '13');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `studentid` int(20) NOT NULL,
  `studentname` varchar(30) NOT NULL,
  `branch` varchar(16) NOT NULL,
  `year` varchar(10) NOT NULL,
  `quota` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `amount` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`studentid`, `studentname`, `branch`, `year`, `quota`, `email`, `mobile`, `amount`) VALUES
(1, 'aaa', 'CSE', '1st', 'convinier', 'abcd@gmail.com', '3456789210', '5000'),
(11, 'qq', 'CSE', '1st', 'Management', 'ale@gmail.com', '9392764118', '50000'),
(12, 'tyu', 'CSE', '1st', 'convinier', 'ale@gmail.com', '9123456789', '5000'),
(13, 'aa', 'CSE', '1st', 'Government', 'abcd@gmail.com', '9876543210', '2500'),
(56, 'bbb', 'CSE', '1st', 'minority', 'ale@gmail.com', '9123456789', '5000'),
(71, 'rajeshwari', 'CSE', '1st', 'convinier', 'raj@gmail.com', '890765432', '5000'),
(88, 'abhi', 'CSE', '1st', 'convinier', 'abhi@gmail.com', '890765432', '5000'),
(123, 'abhi', 'CSE', '1st', 'convinier', 'abcd@gmail.com', '9876543219', '5000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`studentid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `studentid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
